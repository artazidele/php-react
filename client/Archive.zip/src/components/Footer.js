import React from 'react'

export function Footer() {

    return (
        <div className="footer-div">
            <h6>Scandiweb Test assignment</h6>
        </div>
    );
};